# grocery-list-app

##Steps of running this project

from the command prompt clone the project

* $git clone https://github.com/techsithgit/grocery-list-app.git
* $cd grocery-list-app
* $npm install
* $node app add --item=tomato --price=20

[watch video](https://youtu.be/QPlwWuM3UIs).
